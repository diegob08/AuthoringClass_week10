<?php
defined('DB_SERVER') ? null : define('DB_SERVER','localhost');
defined('DB_USER') ? null : define('DB_USER','root');
defined('DB_PASS') ? null : define('DB_PASS','root');
defined('DB_NAME') ? null : define('DB_NAME','db_employees');
defined('BASE_URL') ? null : define('BASE_URL','http://localhost:8888/employees_done/');
?>