<form method="get" action="index.php" name="searchform" id="searchform">
<input type="text" name="str" id="str">
<input type="submit" name="submit" id="submit" value="search">
</form>