<div id="content">
	details view.
<?php

?>
</div>