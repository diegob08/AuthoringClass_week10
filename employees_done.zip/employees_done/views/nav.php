			<header>
				<img id="logo" src="images/logo.png" alt="logo">
				<nav>
					<ul>
						<li><a href="index.php?pg=home">Home</a></li>
						<li><a href="index.php?pg=about">About</a></li>
						<li><a href="index.php?pg=work">Work</a></li>
						<li><a href="index.php?pg=contact">Contact</a></li>
					</ul>
				</nav>
			</header>