<?php
include("controllers/Employee.php");
$emp = new Employee();
$emp->loadViews();
?>